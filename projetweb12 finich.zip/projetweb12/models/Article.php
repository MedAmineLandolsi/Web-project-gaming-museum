<?php
class Article {
    private $conn;
    private $table_name = "articles";

    public $Article_ID;
    public $Auteur_ID;
    public $Titre;
    public $Contenu;
    public $Categorie;
    public $Date_Publication;
    public $Statut;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function lire() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY Date_Publication DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function lirePublies() {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE Statut = 'published' 
                  ORDER BY Date_Publication DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function lireDerniers($limit = 3) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE Statut = 'published' 
                  ORDER BY Date_Publication DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }

    public function lireUn() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE Article_ID = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->Article_ID);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            $this->Titre = $row['Titre'];
            $this->Contenu = $row['Contenu'];
            $this->Categorie = $row['Categorie'];
            $this->Date_Publication = $row['Date_Publication'];
            $this->Auteur_ID = $row['Auteur_ID'];
            $this->Statut = $row['Statut'] ?? 'pending';
            return true;
        }
        return false;
    }

    public function creer() {
        $query = "INSERT INTO " . $this->table_name . " 
                 SET Titre=:Titre, Contenu=:Contenu, Categorie=:Categorie, 
                     Auteur_ID=:Auteur_ID, Date_Publication=:Date_Publication, Statut=:Statut";
        
        $stmt = $this->conn->prepare($query);
        
        $this->Titre = htmlspecialchars(strip_tags($this->Titre));
        $this->Contenu = htmlspecialchars(strip_tags($this->Contenu));
        $this->Categorie = htmlspecialchars(strip_tags($this->Categorie));
        $this->Auteur_ID = htmlspecialchars(strip_tags($this->Auteur_ID));
        $this->Statut = htmlspecialchars(strip_tags($this->Statut));
        
        $stmt->bindParam(":Titre", $this->Titre);
        $stmt->bindParam(":Contenu", $this->Contenu);
        $stmt->bindParam(":Categorie", $this->Categorie);
        $stmt->bindParam(":Auteur_ID", $this->Auteur_ID);
        $stmt->bindParam(":Date_Publication", $this->Date_Publication);
        $stmt->bindParam(":Statut", $this->Statut);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function mettreAJour() {
        $query = "UPDATE " . $this->table_name . " 
                 SET Titre=:Titre, Contenu=:Contenu, Categorie=:Categorie, 
                     Auteur_ID=:Auteur_ID, Statut=:Statut
                 WHERE Article_ID=:Article_ID";
        
        $stmt = $this->conn->prepare($query);
        
        $this->Titre = htmlspecialchars(strip_tags($this->Titre));
        $this->Contenu = htmlspecialchars(strip_tags($this->Contenu));
        $this->Categorie = htmlspecialchars(strip_tags($this->Categorie));
        $this->Auteur_ID = htmlspecialchars(strip_tags($this->Auteur_ID));
        $this->Statut = htmlspecialchars(strip_tags($this->Statut));
        $this->Article_ID = htmlspecialchars(strip_tags($this->Article_ID));
        
        $stmt->bindParam(":Titre", $this->Titre);
        $stmt->bindParam(":Contenu", $this->Contenu);
        $stmt->bindParam(":Categorie", $this->Categorie);
        $stmt->bindParam(":Auteur_ID", $this->Auteur_ID);
        $stmt->bindParam(":Statut", $this->Statut);
        $stmt->bindParam(":Article_ID", $this->Article_ID);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function supprimer() {
        try {
            $this->conn->beginTransaction();
            
            $query_delete_comments = "DELETE FROM commentaires WHERE Article_ID = ?";
            $stmt_comments = $this->conn->prepare($query_delete_comments);
            $stmt_comments->bindParam(1, $this->Article_ID);
            $stmt_comments->execute();
            
            $query = "DELETE FROM " . $this->table_name . " WHERE Article_ID = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $this->Article_ID);
            
            if($stmt->execute()) {
                $this->conn->commit();
                return true;
            } else {
                $this->conn->rollBack();
                return false;
            }
            
        } catch (PDOException $exception) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            error_log("Erreur suppression article: " . $exception->getMessage());
            return false;
        }
    }

    public function compterArticles() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
}
?>