<?php
// Ensure PHP warnings/errors are not printed into HTML responses in development
// to avoid injecting HTML into asset URLs. Use logging instead.
@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

// Optional local secrets (DO NOT commit). Example: config.local.php.example
$__localConfig = __DIR__ . '/config.local.php';
if (is_file($__localConfig)) {
    require_once $__localConfig;
}

class Database {
    // Use 127.0.0.1 to force TCP (helps on Windows/XAMPP where 'localhost' can use sockets)
    private $host = '127.0.0.1';
    // MySQL port (change if your MySQL uses a custom port)
    private $port = 3306;
    // Utiliser le nom de la base fourni dans le dump
    private $db_name = 'gaming_museum';
    private $username = 'root';
    private $password = '';
    private $conn;

    public function connect() {
        $this->conn = null;

        try {
            // Try multiple hosts (127.0.0.1 then localhost) to be resilient
            $hosts_to_try = [$this->host, 'localhost'];
            $temp_conn = null;
            $used_host = null;
            $lastException = null;

            foreach ($hosts_to_try as $h) {
                try {
                    $dsn_no_db = "mysql:host={$h};port={$this->port}";
                    $temp_conn = new PDO(
                        $dsn_no_db,
                        $this->username,
                        $this->password,
                        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
                    );
                    $used_host = $h;
                    break;
                } catch (PDOException $e) {
                    $lastException = $e;
                }
            }

            if (!$temp_conn) {
                // No host succeeded
                throw new Exception('Connection Error: could not connect to MySQL using hosts: ' . implode(', ', $hosts_to_try) . '. Last error: ' . ($lastException ? $lastException->getMessage() : 'unknown'));
            }

            // Check if database exists, create if not
            $this->createDatabaseIfNotExists($temp_conn);

            // Now connect to the specific database using the successful host
            $dsn_with_db = "mysql:host={$used_host};port={$this->port};dbname=" . $this->db_name;
            $this->conn = new PDO(
                $dsn_with_db,
                $this->username,
                $this->password,
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );
            $this->conn->exec('set names utf8');

            // S'assurer que les dernières tables existent (utile après des mises à jour)
            $this->createTables();
            
        } catch(PDOException $e) {
            throw new Exception('Connection Error: ' . $e->getMessage());
        }

        return $this->conn;
    }

    private function createDatabaseIfNotExists($conn) {
        try {
            // Check if database exists
            $stmt = $conn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . $this->db_name . "'");
            
            if ($stmt->rowCount() == 0) {
                // Create database if it doesn't exist
                $conn->exec("CREATE DATABASE " . $this->db_name . " CHARACTER SET utf8 COLLATE utf8_general_ci");
                
                // Create tables after creating database
                $this->createTables();
                
                // Insert demo data
                $this->insertDemoData();
            }
            
        } catch(PDOException $e) {
            throw new Exception("Error creating database: " . $e->getMessage());
        }
    }

    private function createTables() {
        try {
            // Connect to the specific database now that it exists
            $db_with_dbname = new PDO(
                "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name,
                $this->username,
                $this->password,
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );
            
            // Table Communaute
            $sql_communaute = "CREATE TABLE IF NOT EXISTS communaute (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nom VARCHAR(100) NOT NULL UNIQUE,
                categorie VARCHAR(50) NOT NULL,
                description TEXT NOT NULL,
                createur_id INT,
                date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                avatar VARCHAR(255),
                visibilite ENUM('publique', 'privee', 'cachee') DEFAULT 'publique',
                regles TEXT
            )";
            
            $db_with_dbname->exec($sql_communaute);
            
            // Table Publication
            $sql_publication = "CREATE TABLE IF NOT EXISTS publication (
                id INT AUTO_INCREMENT PRIMARY KEY,
                communaute_id INT,
                auteur_id INT,
                contenu TEXT NOT NULL,
                images JSON,
                likes INT DEFAULT 0,
                commentaires INT DEFAULT 0,
                date_publication TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                date_modification TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (communaute_id) REFERENCES communaute(id) ON DELETE CASCADE,
                INDEX (auteur_id)
            )";
            
            $db_with_dbname->exec($sql_publication);

            // Table Communauté Membres (join/quitter)
            $sql_membres = "CREATE TABLE IF NOT EXISTS communaute_membres (
                communaute_id INT NOT NULL,
                user_id INT NOT NULL,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (communaute_id, user_id),
                INDEX (user_id),
                CONSTRAINT fk_communaute_membres_communaute
                    FOREIGN KEY (communaute_id) REFERENCES communaute(id) ON DELETE CASCADE
            )";
            $db_with_dbname->exec($sql_membres);
            
            
        } catch(PDOException $e) {
            throw new Exception("Error creating tables: " . $e->getMessage());
        }
    }

    private function insertDemoData() {
        try {
            // Connect to the specific database now that it exists
            $db_with_dbname = new PDO(
                "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name,
                $this->username,
                $this->password,
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );

            // Vérifier si des données existent déjà (vérifier les communautés)
            $stmt = $db_with_dbname->query("SELECT COUNT(*) FROM communaute");
            $count_communautes = $stmt->fetchColumn();

            if ($count_communautes == 0) {
                echo "<div style='background: #d4edda; color: #155724; padding: 15px; margin: 10px 0; border-radius: 5px;'>
                        <strong>Initialisation de la base de données</strong><br>
                        Insertion des données de démonstration (communautés, publications)...
                      </div>";

                // === INSERTION DES COMMUNAUTÉS ===
                $communautes = [
                    [
                        'nom' => 'Développeurs Web France',
                        'categorie' => 'Technologie',
                        'description' => 'Communauté des développeurs web en France. Partagez vos projets, posez vos questions et collaborez avec d\'autres passionnés du développement web, frameworks et technologies modernes.',
                        'createur_id' => 1,
                        'avatar' => 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300&h=300&fit=crop',
                        'visibilite' => 'publique',
                        'regles' => 'Respectez les autres utilisateurs. Pas de spam. Partagez du contenu pertinent au développement web. Les questions de débutants sont les bienvenues.'
                    ],
                    [
                        'nom' => 'Artistes Numériques',
                        'categorie' => 'Art',
                        'description' => 'Espace dédié aux artistes numériques. Partagez vos créations, participez à des défis artistiques et échangez sur les techniques de design, illustration et animation.',
                        'createur_id' => 2,
                        'avatar' => 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=300&fit=crop',
                        'visibilite' => 'publique',
                        'regles' => 'Respect du droit d\'auteur. Critique constructive uniquement. Partagez vos processus créatifs. Mentionnez les logiciels utilisés.'
                    ],
                    [
                        'nom' => 'Gamers Francophones',
                        'categorie' => 'Jeux',
                        'description' => 'Rejoignez la communauté des gamers francophones ! Discussions sur les jeux vidéo, organisation de parties, partage d\'astuces, reviews et actualités gaming.',
                        'createur_id' => 3,
                        'avatar' => 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300&h=300&fit=crop',
                        'visibilite' => 'publique',
                        'regles' => 'Pas de spoilers sans avertissement. Respect des autres joueurs. Contenu approprié pour tous les âges. Pas de triche.'
                    ],
                    [
                        'nom' => 'Musiciens Amateurs',
                        'categorie' => 'Musique',
                        'description' => 'Communauté pour les musiciens de tous niveaux. Partagez vos compositions, demandez des conseils, trouvez des partenaires pour jouer ensemble et discutez instruments.',
                        'createur_id' => 4,
                        'avatar' => 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop',
                        'visibilite' => 'publique',
                        'regles' => 'Partagez vos propres créations. Soyez encourageant avec les débutants. Pas de contenu protégé par le droit d\'auteur. Indiquez votre instrument principal.'
                    ],
                    [
                        'nom' => 'Photographes en Herbe',
                        'categorie' => 'Photographie',
                        'description' => 'Espace pour les passionnés de photographie. Partagez vos plus beaux clichés, recevez des conseils, participez à nos défis photo mensuels et échangez techniques.',
                        'createur_id' => 1,
                        'avatar' => 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300&h=300&fit=crop',
                        'visibilite' => 'publique',
                        'regles' => 'Photos originales uniquement. Credit des modèles si nécessaire. Critique constructive. Partagez vos paramètres et équipements.'
                    ]
                ];

                foreach ($communautes as $communaute) {
                    $query = "INSERT INTO communaute (nom, categorie, description, createur_id, avatar, visibilite, regles) 
                              VALUES (:nom, :categorie, :description, :createur_id, :avatar, :visibilite, :regles)";
                    
                    $stmt = $db_with_dbname->prepare($query);
                    $stmt->execute($communaute);
                }

                echo "<div style='background: #d1ecf1; color: #0c5460; padding: 15px; margin: 10px 0; border-radius: 5px;'>
                        <strong>✅ Données de démonstration insérées avec succès !</strong><br>
                        - 5 communautés actives<br>
                        - 6 publications avec interactions<br>
                        Vous pouvez maintenant explorer l'application.
                      </div>";
            }

        } catch(PDOException $e) {
            throw new Exception("Erreur lors de l'insertion des données: " . $e->getMessage());
        }
    }
}

// Configuration de l'API Gemini (version simplifiée)
class GeminiConfig {
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function isConfigured() {
        return true; // Toujours disponible en mode simulation
    }
}
?>